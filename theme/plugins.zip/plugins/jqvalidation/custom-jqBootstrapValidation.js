$(function () {

    $(".email input").jqBootstrapValidation();
    $(".max-len input").jqBootstrapValidation();
    $(".min-len input").jqBootstrapValidation();
    $(".pattern input").jqBootstrapValidation();
    $(".confirm-match input").jqBootstrapValidation();
    $(".mix-validation input").jqBootstrapValidation();
    $(".form-val-1 input").jqBootstrapValidation();

});